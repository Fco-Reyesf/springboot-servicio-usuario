package com.example.prueba._tecnica.modulos.user.dto;

public record UserDTO(
        Integer id,
        String name,
        String email
) {
}
